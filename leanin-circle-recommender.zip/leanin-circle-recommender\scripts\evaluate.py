"""Print recommendations for the planted scenario users (or any ids) with score breakdowns.

    python -m scripts.evaluate [user_id ...]
"""

import sys
from pathlib import Path

from app import database as db
from app.service import recommendations_for

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "data" / "leanin.db"

if __name__ == "__main__":
    if not DB_PATH.exists():
        db.build_database(DB_PATH, ROOT / "data")
    conn = db.connect(DB_PATH)
    ids = [int(a) for a in sys.argv[1:]] or [42, 7, 15, 23]
    for uid in ids:
        user = db.get_user(conn, uid)
        interests = db.get_user_interests(conn, uid)
        joined = [m["id"] for m in db.get_user_memberships(conn, uid)]
        result, as_of, _ = recommendations_for(conn, uid, 10)
        print(f"\n=== user {uid} | interests={interests} | member_of={joined} | location={user['location']} | strategy={result.strategy}")
        print(f"    excluded: {result.excluded}")
        for i, sc in enumerate(result.items, 1):
            c, comp = sc.circle, sc.components
            print(
                f"{i:>2}. #{c.id:<3}{c.name:<28} {sc.score:.3f}  rel={comp['relevance']:.2f} act={comp['activity']:.2f} "
                f"acc={comp['accessibility']:.2f} open={comp['openness']:.2f} q={comp['quality']:.2f}  [{c.topic}, {c.format}, {c.join_policy}]"
            )
            print(f"      {sc.reason}")
