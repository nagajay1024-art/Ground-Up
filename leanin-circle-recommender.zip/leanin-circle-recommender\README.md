# Lean In Circle Recommender

An API that recommends Lean In Circles to a member: a ranked list where every result comes with a short, honest, member-facing reason. It is built for the four scenarios in the take-home (cold start, obvious matches, duplicate Circles, full/inactive Circles) and returns sensible results for all 100 users in the seed data.

See **[TECHNICAL_DESIGN.md](TECHNICAL_DESIGN.md)** for the one-page design and tradeoffs.

## Stack

Python 3.11 · FastAPI · SQLite (stdlib `sqlite3`, parameterized SQL) · Pydantic · pytest. No external services, ML models or API keys.

## Setup

Requires Python 3.11+.

```bash
python -m venv .venv
# Windows (PowerShell):  .venv\Scripts\Activate.ps1
# macOS / Linux:         source .venv/bin/activate
pip install -r requirements.txt
```

### Database

The SQLite database (`data/leanin.db`, git-ignored) is **built automatically from `data/*.json` on first start**. To rebuild it explicitly:

```bash
python -m scripts.load_data
```

The seed JSON is never modified. Optional environment variables:

| Variable | Default | Purpose |
| --- | --- | --- |
| `LEANIN_DB_PATH` | `data/leanin.db` | SQLite file location |
| `LEANIN_DATA_DIR` | `data` | Seed JSON directory |
| `LEANIN_AS_OF` | latest timestamp in the data | Reference "now" for activity calculations (ISO 8601) |
| `LOG_LEVEL` | `INFO` | |

> **Why `LEANIN_AS_OF`?** The seed is a snapshot taken at 2026-09-21. If we measured activity against the wall clock, every Circle would look a little more stale each day. By default the service uses the snapshot's latest timestamp as "now"; in production this would be the current time.

### Run

```bash
uvicorn app.main:app --reload
```

Interactive docs: http://127.0.0.1:8000/docs

### Test

```bash
python -m pytest -q
```

## API

### `GET /api/v1/users/{user_id}/recommendations`

| Param | Type | Default | Notes |
| --- | --- | --- | --- |
| `user_id` (path) | int ≥ 1 | | `404` if the user doesn't exist, `422` if not a positive integer |
| `limit` | int 1–20 | 10 | `422` outside the range |
| `debug` | bool | false | Adds the internal `score_breakdown` (for evaluation; not member-facing) |

`strategy` tells you which path produced the list: `stated_interests`, `membership_topics` (no stated interests, so topics of her current Circles are used), or `cold_start`.

```bash
curl "http://127.0.0.1:8000/api/v1/users/23/recommendations?limit=3"
```

Actual response (user 23: interested in *getting promoted*; the full #20 and inactive #21 are filtered out):

```json
{
  "user_id": 23,
  "strategy": "stated_interests",
  "as_of": "2026-09-21T00:00:00.000Z",
  "recommendations": [
    {
      "rank": 1, "circle_id": 22, "name": "Level Up Collective", "slug": "level-up-collective",
      "topic": {"slug": "getting-promoted", "label": "Getting promoted"},
      "format": "hybrid", "join_policy": "request", "member_count": 14, "spots_left": 6,
      "score": 0.8188,
      "reason": "Focused on getting promoted, a topic you're interested in — very active, with 8 posts in the last 30 days.",
      "score_breakdown": null
    },
    {
      "rank": 2, "circle_id": 19, "name": "Working Mothers United", "slug": "working-mothers-united",
      "topic": {"slug": "working-motherhood", "label": "Working motherhood"},
      "format": "in_person", "join_policy": "request", "member_count": 10, "spots_left": null,
      "score": 0.5743,
      "reason": "Centers on working motherhood and also touches on getting promoted, one of your interests — very active, with 9 posts in the last 30 days.",
      "score_breakdown": null
    },
    {
      "rank": 3, "circle_id": 2, "name": "Next Chapter Circle", "slug": "next-chapter-circle",
      "topic": {"slug": "career-breaks", "label": "Career breaks"},
      "format": "virtual", "join_policy": "open", "member_count": 14, "spots_left": null,
      "score": 0.5682,
      "reason": "Centers on career breaks and also touches on getting promoted, one of your interests — 6 posts in the last 30 days.",
      "score_breakdown": null
    }
  ]
}
```

`spots_left: null` means the Circle has no member cap.

More examples:

```bash
curl "http://127.0.0.1:8000/api/v1/users/42/recommendations"            # cold start
curl "http://127.0.0.1:8000/api/v1/users/15/recommendations?debug=true" # with score breakdown
curl "http://127.0.0.1:8000/health"                                      # {"status":"ok","circles":40}
```

### Scenario results (from `python -m scripts.evaluate`)

| Scenario | User | Result |
| --- | --- | --- |
| Cold start | 42 | 10 active, public Circles, one per topic. Hybrid and virtual are favoured (her location is unknown) and open-to-join ranks higher. #1: *The Negotiation Table*: "A very active hybrid Circle on negotiation — 13 posts in the last 30 days and open to new members." No interests are claimed. |
| Obvious matches | 7 | #1 *Speak Up Circle* (#6, matches both her interests), #2 *Women Who Lead* (#5). *Speak With Impact* (#38) is collapsed as a near-duplicate of #6 (same topic, same in-person format, "speak" in both names). |
| Duplicate Circles | 15 | *The Negotiation Table* (#11, hybrid) and *Negotiation Circle* (#10, in-person) are kept because the formats differ. *Negotiate Like a Leader* (#12) is dropped as a near-duplicate of #10 (same topic, same format, "negotiat-" in both names). Top 4: #13, #11, #10, #37. |
| Full / inactive | 23 | #22 *Level Up Collective* ranks first. #20 is excluded (15/15 members) and #21 is excluded (no activity since February; also unlisted). |

## How ranking works (short version)

1. **Filter:** remove Circles she has already joined, unlisted, full, or dormant (no activity in 60 days).
2. **Score** 0–1: relevance to her interests 55%, recent activity and engagement 25%, format accessibility 8%, open-to-join 7%, has a description/cover 5%. Cold start drops relevance and leans on activity, accessibility and openness.
3. **Diversify:** collapse near-identical Circles (including ones near-identical to a Circle she's in) and gently discount repeated topics.
4. **Explain:** a template sentence that uses only facts from the data.

Details and rationale: [TECHNICAL_DESIGN.md](TECHNICAL_DESIGN.md).

## Database schema

Defined in [`app/database.py`](app/database.py).

```
topics(id PK, slug UNIQUE, label, domain)
users(id PK, first_name, last_name, has_photo, bio, job_title, company, industry, location, joined_at, profile_completeness)
user_topic_interests(user_id FK→users, topic_slug FK→topics.slug, PK(user_id, topic_slug))   idx(topic_slug)
circles(id PK, name, slug UNIQUE, description, topic_slug FK→topics.slug NULL, cover_image_url,
        format CHECK, access CHECK, join_policy CHECK, max_members NULL=uncapped, member_count,
        created_at, last_activity_at, feed_posts_30d, chat_messages_30d)                       idx(topic_slug), idx(access)
circle_tags(circle_id FK→circles, tag, PK(circle_id, tag))                                     idx(tag)
memberships(user_id FK→users, circle_id FK→circles, role CHECK(member|leader), joined_at,
            PK(user_id, circle_id))                                                           idx(circle_id, role)
activity_posts(id PK, circle_id FK→circles, author_user_id FK→users, body, reaction_count,
               comment_count, save_count, created_at)                                         idx(circle_id, created_at)
```

- **Many-to-many:** users↔topics (interests), users↔circles (memberships, with `role`; leaders are members with `role=leader`), circles↔tags.
- **Indexes follow the query path:** the membership PK, leading with `user_id`, answers "which Circles is she in" (exclusion). `(circle_id, role)` answers leader lookups. `(circle_id, created_at)` answers 30-day engagement. The topic/tag indexes support topic-driven candidate retrieval at scale.
- **Tags are not a foreign key** because the source describes them as free-form. A duplicated tag in the seed (#17) is de-duplicated by the PK.
- **Fullness and dormancy are derived at query time**, not stored, so they can't drift from the underlying counts.

## Project structure

```
app/
  main.py          FastAPI app, routes, validation, error handling
  schemas.py       Pydantic response models
  service.py       DB rows -> typed objects; reference-time resolution
  recommender.py   Pure ranking: eligibility, scoring, diversity, explanations
  database.py      Schema DDL, seed loader, parameterized queries
scripts/
  load_data.py     Rebuild SQLite from seed JSON
  evaluate.py      Print ranked lists + score breakdowns for chosen users
tests/
  test_recommender.py  Unit tests: one policy per test, synthetic Circles
  test_api.py          Integration tests on seed data, incl. all four scenarios
                       and property checks over all 100 users
data/              Original seed dataset (JSON, generator, data dictionary) — unmodified
```

## Design tradeoffs

- **Rules over ML:** with 40 Circles and no join/feedback data there is nothing to train on, and rules make every explanation traceable. The scorer is designed to become the re-ranking stage once a learned model exists.
- **Hard filters for full and dormant Circles** rather than a score penalty, so a strong topic match can never surface a Circle she can't join or one that won't respond.
- **No inference from bio or job title**, to avoid guessing interests she hasn't expressed. Circles also have no industry or location fields to match against.
- **SQLite + raw SQL** keeps setup to one `pip install`; the schema is portable to Postgres.

## Verification status

Verified on Windows 11 with Python 3.11.9: install, auto DB build, `uvicorn` start, the curl calls above, and `python -m pytest -q` → **47 passed**. The macOS/Linux activation command is standard but was not run on those platforms.
