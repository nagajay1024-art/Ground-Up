"""Glue between the database and the pure recommender."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from app import database as db
from app.recommender import Circle, Recommendations, UserContext, recent_window_start, recommend


class UserNotFound(Exception):
    pass


def parse_ts(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def format_ts(value: datetime) -> str:
    # Matches the seed's storage format so string comparison in SQL is chronological.
    return value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + f"{value.microsecond // 1000:03d}Z"


def resolve_as_of(conn: sqlite3.Connection, override: str | None) -> datetime:
    """The seed is a snapshot, so 'now' defaults to its latest timestamp rather than the wall clock;
    otherwise every Circle would look stale. LEANIN_AS_OF can override it."""
    if override:
        return parse_ts(override)
    snapshot = parse_ts(db.get_dataset_as_of(conn))
    return snapshot or datetime.now(timezone.utc)


def load_circles(conn: sqlite3.Connection, as_of: datetime) -> list[Circle]:
    rows = db.get_candidate_circles(conn, format_ts(recent_window_start(as_of)))
    return [
        Circle(
            id=r["id"],
            name=r["name"],
            slug=r["slug"],
            description=r["description"],
            topic=r["topic_slug"],
            tags=tuple(r["tags"]),
            cover_image_url=r["cover_image_url"],
            format=r["format"],
            access=r["access"],
            join_policy=r["join_policy"],
            max_members=r["max_members"],
            member_count=r["member_count"],
            last_activity_at=parse_ts(r["last_activity_at"]),
            feed_posts_30d=r["feed_posts_30d"] or 0,
            chat_messages_30d=r["chat_messages_30d"] or 0,
            last_post_at=parse_ts(r["last_post_at"]),
            recent_posts=r["recent_posts"] or 0,
            recent_engagement=r["recent_engagement"] or 0,
        )
        for r in rows
    ]


def load_user(conn: sqlite3.Connection, user_id: int) -> UserContext:
    row = db.get_user(conn, user_id)
    if row is None:
        raise UserNotFound(user_id)
    return UserContext(
        user_id=user_id,
        interests=tuple(db.get_user_interests(conn, user_id)),
        member_circles=tuple((m["id"], m["name"], m["topic_slug"]) for m in db.get_user_memberships(conn, user_id)),
        location=row["location"],
    )


def recommendations_for(
    conn: sqlite3.Connection, user_id: int, limit: int, as_of_override: str | None = None
) -> tuple[Recommendations, datetime, dict[str, str]]:
    user = load_user(conn, user_id)
    as_of = resolve_as_of(conn, as_of_override)
    labels = db.get_topic_labels(conn)
    return recommend(user, load_circles(conn, as_of), labels, as_of, limit), as_of, labels
