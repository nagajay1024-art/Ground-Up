"""SQLite schema, seed loading, and the read queries the recommender needs."""

from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path

logger = logging.getLogger(__name__)

SCHEMA = """
CREATE TABLE topics (
    id      INTEGER PRIMARY KEY,
    slug    TEXT NOT NULL UNIQUE,
    label   TEXT NOT NULL,
    domain  TEXT NOT NULL
);

CREATE TABLE users (
    id                   INTEGER PRIMARY KEY,
    first_name           TEXT NOT NULL,
    last_name            TEXT NOT NULL,
    has_photo            INTEGER NOT NULL CHECK (has_photo IN (0, 1)),
    bio                  TEXT,
    job_title            TEXT,
    company              TEXT,
    industry             TEXT,
    location             TEXT,
    joined_at            TEXT NOT NULL,
    profile_completeness REAL NOT NULL CHECK (profile_completeness BETWEEN 0 AND 1)
);

-- Many-to-many: users <-> topics (stated interests).
CREATE TABLE user_topic_interests (
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    topic_slug TEXT    NOT NULL REFERENCES topics(slug),
    PRIMARY KEY (user_id, topic_slug)
);
CREATE INDEX idx_user_topic_interests_topic ON user_topic_interests(topic_slug);

CREATE TABLE circles (
    id                INTEGER PRIMARY KEY,
    name              TEXT NOT NULL,
    slug              TEXT NOT NULL UNIQUE,
    description       TEXT,
    topic_slug        TEXT REFERENCES topics(slug),          -- nullable: some Circles have no topic
    cover_image_url   TEXT,
    format            TEXT NOT NULL CHECK (format IN ('in_person', 'virtual', 'hybrid')),
    access            TEXT NOT NULL CHECK (access IN ('public', 'unlisted')),
    join_policy       TEXT NOT NULL CHECK (join_policy IN ('open', 'request')),
    max_members       INTEGER CHECK (max_members IS NULL OR max_members > 0),  -- NULL = uncapped
    member_count      INTEGER NOT NULL CHECK (member_count >= 0),
    created_at        TEXT NOT NULL,
    last_activity_at  TEXT,
    feed_posts_30d    INTEGER NOT NULL DEFAULT 0,
    chat_messages_30d INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_circles_topic ON circles(topic_slug);
-- Candidate retrieval filters on discoverability first.
CREATE INDEX idx_circles_access ON circles(access);

-- Tags are free-form in the source data, so they are not a foreign key to topics.
CREATE TABLE circle_tags (
    circle_id INTEGER NOT NULL REFERENCES circles(id) ON DELETE CASCADE,
    tag       TEXT    NOT NULL,
    PRIMARY KEY (circle_id, tag)
);
CREATE INDEX idx_circle_tags_tag ON circle_tags(tag);

CREATE TABLE memberships (
    user_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    circle_id INTEGER NOT NULL REFERENCES circles(id) ON DELETE CASCADE,
    role      TEXT    NOT NULL CHECK (role IN ('member', 'leader')),
    joined_at TEXT    NOT NULL,
    PRIMARY KEY (user_id, circle_id)          -- also serves "which Circles is this user in?"
);
CREATE INDEX idx_memberships_circle_role ON memberships(circle_id, role);

CREATE TABLE activity_posts (
    id             INTEGER PRIMARY KEY,
    circle_id      INTEGER NOT NULL REFERENCES circles(id) ON DELETE CASCADE,
    author_user_id INTEGER NOT NULL REFERENCES users(id),
    body           TEXT    NOT NULL,
    reaction_count INTEGER NOT NULL DEFAULT 0,
    comment_count  INTEGER NOT NULL DEFAULT 0,
    save_count     INTEGER NOT NULL DEFAULT 0,
    created_at     TEXT    NOT NULL
);
-- Recent-engagement aggregation is always "posts for circle X since date Y".
CREATE INDEX idx_activity_circle_created ON activity_posts(circle_id, created_at);
"""


def connect(db_path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _load_json(data_dir: Path, name: str) -> list[dict]:
    with open(data_dir / f"{name}.json", encoding="utf-8") as f:
        return json.load(f)


def build_database(db_path: str | Path, data_dir: str | Path) -> None:
    """(Re)create the SQLite database from the seed JSON files. Seed files are never modified."""
    db_path, data_dir = Path(db_path), Path(data_dir)
    if db_path.exists():
        db_path.unlink()
    conn = connect(db_path)
    try:
        conn.executescript(SCHEMA)
        topics = _load_json(data_dir, "topics")
        users = _load_json(data_dir, "users")
        circles = _load_json(data_dir, "circles")
        memberships = _load_json(data_dir, "memberships")
        activity = _load_json(data_dir, "activity")

        conn.executemany(
            "INSERT INTO topics (id, slug, label, domain) VALUES (:id, :slug, :label, :domain)", topics
        )
        conn.executemany(
            """INSERT INTO users (id, first_name, last_name, has_photo, bio, job_title, company,
                                  industry, location, joined_at, profile_completeness)
               VALUES (:id, :first_name, :last_name, :has_photo, :bio, :job_title, :company,
                       :industry, :location, :joined_at, :profile_completeness)""",
            users,
        )
        # INSERT OR IGNORE: the seed contains a repeated tag on one Circle; repeats carry no extra meaning.
        conn.executemany(
            "INSERT OR IGNORE INTO user_topic_interests (user_id, topic_slug) VALUES (?, ?)",
            [(u["id"], slug) for u in users for slug in u.get("topic_interests") or []],
        )
        conn.executemany(
            """INSERT INTO circles (id, name, slug, description, topic_slug, cover_image_url, format,
                                    access, join_policy, max_members, member_count, created_at,
                                    last_activity_at, feed_posts_30d, chat_messages_30d)
               VALUES (:id, :name, :slug, :description, :topic, :cover_image_url, :format, :access,
                       :join_policy, :max_members, :member_count, :created_at, :last_activity_at,
                       :feed_posts_30d, :chat_messages_30d)""",
            circles,
        )
        conn.executemany(
            "INSERT OR IGNORE INTO circle_tags (circle_id, tag) VALUES (?, ?)",
            [(c["id"], tag) for c in circles for tag in c.get("tags") or []],
        )
        conn.executemany(
            """INSERT INTO memberships (user_id, circle_id, role, joined_at)
               VALUES (:user_id, :circle_id, :role, :joined_at)""",
            memberships,
        )
        conn.executemany(
            """INSERT INTO activity_posts (id, circle_id, author_user_id, body, reaction_count,
                                           comment_count, save_count, created_at)
               VALUES (:id, :circle_id, :author_user_id, :body, :reaction_count, :comment_count,
                       :save_count, :created_at)""",
            activity,
        )
        conn.commit()
        logger.info(
            "Built %s: %d users, %d circles, %d memberships, %d posts",
            db_path, len(users), len(circles), len(memberships), len(activity),
        )
    finally:
        conn.close()


# ---- read queries -----------------------------------------------------------

def get_user(conn: sqlite3.Connection, user_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


def get_user_interests(conn: sqlite3.Connection, user_id: int) -> list[str]:
    rows = conn.execute(
        "SELECT topic_slug FROM user_topic_interests WHERE user_id = ? ORDER BY topic_slug", (user_id,)
    )
    return [r["topic_slug"] for r in rows]


def get_user_memberships(conn: sqlite3.Connection, user_id: int) -> list[sqlite3.Row]:
    return conn.execute(
        """SELECT c.id, c.name, c.topic_slug
             FROM memberships m JOIN circles c ON c.id = m.circle_id
            WHERE m.user_id = ?
            ORDER BY c.id""",
        (user_id,),
    ).fetchall()


def get_topic_labels(conn: sqlite3.Connection) -> dict[str, str]:
    return {r["slug"]: r["label"] for r in conn.execute("SELECT slug, label FROM topics")}


def get_dataset_as_of(conn: sqlite3.Connection) -> str | None:
    """Latest timestamp observed in the data: the snapshot's 'now'."""
    row = conn.execute(
        """SELECT MAX(ts) AS as_of FROM (
               SELECT MAX(last_activity_at) AS ts FROM circles
               UNION ALL SELECT MAX(created_at) FROM activity_posts)"""
    ).fetchone()
    return row["as_of"]


def get_candidate_circles(conn: sqlite3.Connection, since: str) -> list[dict]:
    """All Circles with their tags and engagement on feed posts created on/after `since`."""
    rows = conn.execute(
        """SELECT c.*,
                  (SELECT GROUP_CONCAT(tag, '|') FROM (SELECT tag FROM circle_tags t
                        WHERE t.circle_id = c.id ORDER BY tag))                         AS tags,
                  (SELECT MAX(created_at) FROM activity_posts p WHERE p.circle_id = c.id) AS last_post_at,
                  (SELECT COUNT(*) FROM activity_posts p
                    WHERE p.circle_id = c.id AND p.created_at >= ?)                      AS recent_posts,
                  (SELECT COALESCE(SUM(reaction_count + comment_count + save_count), 0)
                     FROM activity_posts p
                    WHERE p.circle_id = c.id AND p.created_at >= ?)                      AS recent_engagement
             FROM circles c
            ORDER BY c.id""",
        (since, since),
    ).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["tags"] = d["tags"].split("|") if d["tags"] else []
        out.append(d)
    return out
