from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class Topic(BaseModel):
    slug: str
    label: str


class ScoreBreakdown(BaseModel):
    relevance: float
    activity: float
    accessibility: float
    openness: float
    quality: float


class Recommendation(BaseModel):
    rank: int
    circle_id: int
    name: str
    slug: str
    topic: Topic | None
    format: Literal["in_person", "virtual", "hybrid"]
    join_policy: Literal["open", "request"]
    member_count: int
    spots_left: int | None = Field(description="null means the Circle has no member cap")
    score: float = Field(ge=0, le=1)
    reason: str
    score_breakdown: ScoreBreakdown | None = Field(default=None, description="Only returned with debug=true")


class RecommendationResponse(BaseModel):
    user_id: int
    strategy: Literal["stated_interests", "membership_topics", "cold_start"]
    as_of: str = Field(description="Reference time used for activity calculations")
    recommendations: list[Recommendation]


class HealthResponse(BaseModel):
    status: Literal["ok"]
    circles: int
