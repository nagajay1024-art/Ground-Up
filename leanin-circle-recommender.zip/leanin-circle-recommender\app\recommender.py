"""Deterministic, explainable Circle ranking.

Pipeline: eligibility filter -> score (relevance + activity + accessibility + openness + profile
quality) -> diversity re-rank (collapse near-duplicates, cap per topic) -> member-facing reason.
Everything here is pure: callers pass in plain data, so it is unit-testable without a database.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta

# ---- policy constants -------------------------------------------------------

INACTIVE_AFTER_DAYS = 60       # no activity of any kind for 2 months => dormant, never recommended
MIN_CHAT_WITHOUT_POSTS = 5     # zero feed posts in 30d and fewer chat messages than this => dormant
RECENT_WINDOW_DAYS = 30

# Weights when we know something about what the member cares about. Relevance dominates so
# popularity can't outrank a real topic match: an exact topic match contributes up to 0.55 while a
# zero-relevance Circle can reach at most 0.45 from every other signal combined.
PERSONALIZED_WEIGHTS = {"relevance": 0.55, "activity": 0.25, "accessibility": 0.08, "openness": 0.07, "quality": 0.05}
# Cold start: no stated or implied interests, so rank on how good a first experience a Circle is.
COLD_START_WEIGHTS = {"relevance": 0.0, "activity": 0.55, "accessibility": 0.20, "openness": 0.15, "quality": 0.10}

# How strongly a Circle field matching an interest counts.
MATCH_PRIMARY_TOPIC = 1.0
MATCH_TAG = 0.5                # tags are free-form and noisier than the primary topic
MATCH_TEXT = 0.3               # interest label appears in name/description
IMPLIED_INTEREST_WEIGHT = 0.6  # topics of Circles the member already joined (used only with no stated interests)

FORMAT_ACCESSIBILITY = {"virtual": 1.0, "hybrid": 0.85, "in_person": 0.6}
FORMAT_ACCESSIBILITY_REMOTE = {"virtual": 1.0, "hybrid": 0.7, "in_person": 0.3}

# Diminishing returns for repeating a primary topic: the k-th Circle on an already-shown topic has
# its score multiplied by DECAY**k. Soft (not a hard cap) so a strong match still beats filler.
TOPIC_REPEAT_DECAY_PERSONALIZED = 0.9  # gentle: a member's own topic repeating is often what she wants
TOPIC_REPEAT_DECAY_COLD_START = 0.5   # cold-start lists should show breadth, not assume a topic

GENERIC_NAME_WORDS = {
    "the", "a", "an", "and", "of", "to", "for", "with", "like", "who", "your", "circle", "circles",
    "women", "group", "collective", "club", "lab", "room", "guild", "united", "coalition",
}


# ---- data shapes ------------------------------------------------------------

@dataclass(frozen=True)
class Circle:
    id: int
    name: str
    slug: str
    description: str | None
    topic: str | None
    tags: tuple[str, ...]
    cover_image_url: str | None
    format: str
    access: str
    join_policy: str
    max_members: int | None
    member_count: int
    last_activity_at: datetime | None
    feed_posts_30d: int
    chat_messages_30d: int
    last_post_at: datetime | None = None
    recent_posts: int = 0
    recent_engagement: int = 0

    @property
    def spots_left(self) -> int | None:
        return None if self.max_members is None else max(0, self.max_members - self.member_count)

    @property
    def is_full(self) -> bool:
        return self.max_members is not None and self.member_count >= self.max_members

    @property
    def effective_last_activity(self) -> datetime | None:
        # last_activity_at in the seed can lag behind the newest feed post; trust whichever is later.
        stamps = [t for t in (self.last_activity_at, self.last_post_at) if t is not None]
        return max(stamps) if stamps else None


@dataclass(frozen=True)
class UserContext:
    user_id: int
    interests: tuple[str, ...]                          # stated topic slugs
    member_circles: tuple[tuple[int, str, str | None], ...] = ()  # (circle_id, name, topic)
    location: str | None = None

    @property
    def member_circle_ids(self) -> frozenset[int]:
        return frozenset(cid for cid, _, _ in self.member_circles)


@dataclass(frozen=True)
class InterestSignal:
    topic: str
    weight: float
    source: str                   # "stated" | "membership"
    via_circle: str | None = None  # for membership-implied interests: which Circle implied it


@dataclass(frozen=True)
class Match:
    topic: str
    kind: str                     # "topic" | "tag" | "text"
    strength: float
    signal: InterestSignal


@dataclass
class ScoredCircle:
    circle: Circle
    score: float
    components: dict[str, float]
    matches: list[Match] = field(default_factory=list)
    reason: str = ""


@dataclass
class Recommendations:
    strategy: str                 # "stated_interests" | "membership_topics" | "cold_start"
    items: list[ScoredCircle]
    excluded: dict[int, list[str]]  # circle_id -> why it was filtered (debugging/evaluation only)


# ---- eligibility ------------------------------------------------------------

def days_since(ts: datetime | None, as_of: datetime) -> float | None:
    if ts is None:
        return None
    return max(0.0, (as_of - ts).total_seconds() / 86400)


def is_dormant(circle: Circle, as_of: datetime) -> bool:
    """No activity evidence => dormant. We never tell a member a Circle is lively without proof."""
    idle = days_since(circle.effective_last_activity, as_of)
    if idle is None or idle > INACTIVE_AFTER_DAYS:
        return True
    return circle.feed_posts_30d == 0 and circle.chat_messages_30d < MIN_CHAT_WITHOUT_POSTS


def ineligibility_reasons(circle: Circle, user: UserContext, as_of: datetime) -> list[str]:
    reasons = []
    if circle.id in user.member_circle_ids:
        reasons.append("already_member")
    if circle.access != "public":
        reasons.append("not_discoverable")   # unlisted Circles are shared by invitation, not surfaced to strangers
    if circle.is_full:
        reasons.append("full")
    if is_dormant(circle, as_of):
        reasons.append("inactive")
    return reasons


# ---- signals ----------------------------------------------------------------

def interest_signals(user: UserContext) -> tuple[str, list[InterestSignal]]:
    if user.interests:
        return "stated_interests", [InterestSignal(t, 1.0, "stated") for t in user.interests]
    implied: dict[str, InterestSignal] = {}
    for _, name, topic in sorted(user.member_circles):
        if topic and topic not in implied:
            implied[topic] = InterestSignal(topic, IMPLIED_INTEREST_WEIGHT, "membership", via_circle=name)
    if implied:
        return "membership_topics", list(implied.values())
    return "cold_start", []


def find_matches(circle: Circle, signals: list[InterestSignal], labels: dict[str, str]) -> list[Match]:
    text = f"{circle.name} {circle.description or ''}".lower()
    matches = []
    for s in signals:
        if circle.topic == s.topic:
            kind, strength = "topic", MATCH_PRIMARY_TOPIC
        elif s.topic in circle.tags:
            kind, strength = "tag", MATCH_TAG
        elif labels.get(s.topic, s.topic).lower() in text:
            kind, strength = "text", MATCH_TEXT
        else:
            continue
        matches.append(Match(s.topic, kind, strength * s.weight, s))
    matches.sort(key=lambda m: (-m.strength, m.topic))
    return matches


def relevance_score(matches: list[Match]) -> float:
    """Best match carries most of the weight; extra matched interests add a bounded bonus."""
    if not matches:
        return 0.0
    rest = sum(m.strength for m in matches[1:])
    return 0.8 * matches[0].strength + 0.2 * min(1.0, rest)


def activity_score(circle: Circle, as_of: datetime) -> float:
    posts = min(1.0, circle.feed_posts_30d / 12)
    chat = min(1.0, math.log1p(circle.chat_messages_30d) / math.log1p(150))
    idle = days_since(circle.effective_last_activity, as_of)
    recency = 0.0 if idle is None else 0.5 ** (idle / 10)          # 10-day half-life
    per_post = circle.recent_engagement / circle.recent_posts if circle.recent_posts else 0.0
    engagement = min(1.0, per_post / 15)                           # reactions+comments+saves per post
    return 0.35 * posts + 0.20 * chat + 0.25 * recency + 0.20 * engagement


def accessibility_score(circle: Circle, user: UserContext) -> float:
    # Circles carry no location, so we can't tell whether an in-person Circle is nearby; formats
    # that work from anywhere are the safer suggestion, especially for members who work remotely.
    table = FORMAT_ACCESSIBILITY_REMOTE if (user.location or "").strip().lower() == "remote" else FORMAT_ACCESSIBILITY
    return table.get(circle.format, 0.5)


def openness_score(circle: Circle) -> float:
    return 1.0 if circle.join_policy == "open" else 0.6


def quality_score(circle: Circle) -> float:
    # A Circle with a description and cover image gives a newcomer something to judge it by.
    return 0.5 * bool(circle.description) + 0.5 * bool(circle.cover_image_url)


# ---- diversity --------------------------------------------------------------

def _name_stems(name: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", name.lower())
    return {w[:6] for w in words if w not in GENERIC_NAME_WORDS and len(w) > 2}


def _jaccard(a: set, b: set) -> float:
    return len(a & b) / len(a | b) if a | b else 0.0


def near_duplicates(a: Circle, b: Circle) -> bool:
    """Same topic, same format, and nothing distinguishing in name or content.

    A different format (e.g. virtual vs in-person) is treated as a legitimately different choice.
    """
    if a.topic is None or a.topic != b.topic or a.format != b.format:
        return False
    if _name_stems(a.name) & _name_stems(b.name):
        return True
    same_text = _jaccard(set((a.description or "").lower().split()), set((b.description or "").lower().split())) >= 0.8
    return same_text and _jaccard(set(a.tags), set(b.tags)) >= 0.5


def _sort_key(sc: ScoredCircle) -> tuple:
    # Deterministic: score desc, then more activity, then lower id.
    return (-sc.score, -sc.components["activity"], sc.circle.id)


def diversify(
    ranked: list[ScoredCircle], limit: int, topic_decay: float, already_joined: list[Circle] = ()
) -> list[ScoredCircle]:
    """Greedy re-rank. Near-duplicates of a better Circle, or of one the member already belongs to,
    are dropped outright (the strongest of each cluster survives because input is score-ordered);
    repeats of an already-shown topic are discounted by `topic_decay` per repeat. The member-facing
    score is the discounted one, so the returned list is always sorted by the score it shows."""
    kept: list[ScoredCircle] = []
    for sc in sorted(ranked, key=_sort_key):
        seen = [k.circle for k in kept] + list(already_joined)
        if not any(near_duplicates(sc.circle, other) for other in seen):
            kept.append(sc)

    chosen: list[ScoredCircle] = []
    topic_counts: dict[str, int] = {}
    remaining = kept
    while remaining and len(chosen) < limit:
        def adjusted(sc: ScoredCircle) -> ScoredCircle:
            repeats = topic_counts.get(sc.circle.topic, 0) if sc.circle.topic else 0
            return ScoredCircle(sc.circle, round(sc.score * topic_decay ** repeats, 4), sc.components, sc.matches)

        best = min((adjusted(sc) for sc in remaining), key=_sort_key)
        chosen.append(best)
        remaining = [sc for sc in remaining if sc.circle.id != best.circle.id]
        if best.circle.topic:
            topic_counts[best.circle.topic] = topic_counts.get(best.circle.topic, 0) + 1
    return chosen


# ---- explanations -----------------------------------------------------------

_FORMAT_WORD = {"virtual": "virtual", "hybrid": "hybrid", "in_person": "in-person"}


def _posts(n: int) -> str:
    return f"{n} post{'s' if n != 1 else ''} in the last 30 days"


def _activity_tail(circle: Circle) -> str:
    # Activity is only claimed when the feed shows it; otherwise we say nothing about it.
    n = circle.feed_posts_30d
    if n >= 8:
        return f" — very active, with {_posts(n)}"
    if n >= 1:
        return f" — {_posts(n)}"
    return ""


def explain(sc: ScoredCircle, labels: dict[str, str]) -> str:
    c = sc.circle
    label = lambda slug: labels.get(slug, slug.replace("-", " ")).lower()

    if sc.matches:
        stated = [m for m in sc.matches if m.signal.source == "stated"]
        top = sc.matches[0]
        if len(stated) >= 2:
            lead = f"Covers {label(stated[0].topic)} and {label(stated[1].topic)}, both topics you're interested in"
        elif top.signal.source == "membership":
            verb = "focuses on" if top.kind == "topic" else "also covers"
            lead = f"Like {top.signal.via_circle}, which you're already in, this Circle {verb} {label(top.topic)}"
        elif top.kind == "topic":
            lead = f"Focused on {label(top.topic)}, a topic you're interested in"
        elif top.kind == "tag" and c.topic:
            lead = f"Centers on {label(c.topic)} and also touches on {label(top.topic)}, one of your interests"
        elif top.kind == "tag":
            lead = f"Touches on {label(top.topic)}, one of your interests"
        else:
            lead = f"Mentions {label(top.topic)}, one of your interests"
        return f"{lead}{_activity_tail(c)}."

    # No topic match (cold start or list filler): describe what the Circle offers without
    # implying the member said they wanted it.
    n = c.feed_posts_30d
    adjective = "very active " if n >= 8 else "active " if n >= 3 else ""
    article = "An" if (adjective or _FORMAT_WORD.get(c.format, "")).startswith(("a", "e", "i", "o", "u")) else "A"
    lead = f"{article} {adjective}{_FORMAT_WORD.get(c.format, '')} Circle".replace("  ", " ")
    if c.topic:
        lead += f" on {label(c.topic)}"
    if c.format == "virtual":
        lead += " you can join from anywhere"
    details = [x for x in (_posts(n) if n else None, "open to new members" if c.join_policy == "open" else None) if x]
    return f"{lead} — {' and '.join(details)}." if details else f"{lead}."


# ---- entry point ------------------------------------------------------------

def recommend(
    user: UserContext,
    circles: list[Circle],
    topic_labels: dict[str, str],
    as_of: datetime,
    limit: int = 10,
) -> Recommendations:
    strategy, signals = interest_signals(user)
    weights = COLD_START_WEIGHTS if strategy == "cold_start" else PERSONALIZED_WEIGHTS

    excluded: dict[int, list[str]] = {}
    scored: list[ScoredCircle] = []
    for c in circles:
        why_not = ineligibility_reasons(c, user, as_of)
        if why_not:
            excluded[c.id] = why_not
            continue
        matches = find_matches(c, signals, topic_labels)
        components = {
            "relevance": relevance_score(matches),
            "activity": activity_score(c, as_of),
            "accessibility": accessibility_score(c, user),
            "openness": openness_score(c),
            "quality": quality_score(c),
        }
        score = sum(weights[k] * v for k, v in components.items())
        scored.append(ScoredCircle(c, round(score, 4), {k: round(v, 4) for k, v in components.items()}, matches))

    decay = TOPIC_REPEAT_DECAY_COLD_START if strategy == "cold_start" else TOPIC_REPEAT_DECAY_PERSONALIZED
    joined = [c for c in circles if c.id in user.member_circle_ids]
    items = diversify(scored, limit, decay, joined)
    for sc in items:
        sc.reason = explain(sc, topic_labels)
    return Recommendations(strategy, items, excluded)


def recent_window_start(as_of: datetime) -> datetime:
    return as_of - timedelta(days=RECENT_WINDOW_DAYS)
