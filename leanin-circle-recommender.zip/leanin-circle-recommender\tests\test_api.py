"""API integration tests against the real seed data, including the four planted scenarios.

Eligibility and explanation facts are checked against the raw JSON, not against the app's own helpers.
"""

import re
from datetime import datetime, timedelta

import pytest

URL = "/api/v1/users/{}/recommendations"


def get(client, user_id, **params):
    return client.get(URL.format(user_id), params=params)


def rec_ids(resp):
    return [r["circle_id"] for r in resp.json()["recommendations"]]


def _ts(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


@pytest.fixture(scope="session")
def unavailable(seed):
    """Circle ids that must never be recommended, derived independently from the raw seed."""
    as_of = max(_ts(c["last_activity_at"]) for c in seed["circles"])
    last_post = {}
    for p in seed["activity"]:
        last_post[p["circle_id"]] = max(last_post.get(p["circle_id"], _ts(p["created_at"])), _ts(p["created_at"]))
    bad = set()
    for c in seed["circles"]:
        full = c["max_members"] is not None and c["member_count"] >= c["max_members"]
        latest = max(_ts(c["last_activity_at"]), last_post.get(c["id"], _ts(c["last_activity_at"])))
        dormant = as_of - latest > timedelta(days=60)
        if full or dormant or c["access"] != "public":
            bad.add(c["id"])
    return bad


# ---- basics -----------------------------------------------------------------

def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.json() == {"status": "ok", "circles": 40}


def test_existing_user_gets_valid_response(client):
    r = get(client, 7)
    assert r.status_code == 200
    body = r.json()
    assert body["user_id"] == 7 and body["strategy"] == "stated_interests"
    assert 1 <= len(body["recommendations"]) <= 10
    first = body["recommendations"][0]
    assert {"rank", "circle_id", "name", "slug", "topic", "format", "join_policy", "member_count",
            "spots_left", "score", "reason"} <= first.keys()
    assert first["rank"] == 1 and first["score_breakdown"] is None


def test_unknown_user_is_404(client):
    r = get(client, 99999)
    assert r.status_code == 404 and "not found" in r.json()["detail"]


@pytest.mark.parametrize("path_id,params", [
    ("abc", {}), ("0", {}), ("-3", {}),
    ("7", {"limit": 0}), ("7", {"limit": 21}), ("7", {"limit": "ten"}), ("7", {"debug": "maybe"}),
])
def test_invalid_parameters_are_422(client, path_id, params):
    assert client.get(URL.format(path_id), params=params).status_code == 422


@pytest.mark.parametrize("limit", [1, 3, 20])
def test_limit_respected(client, limit):
    # Both users have more than 20 eligible Circles, so the list should be exactly `limit` long.
    assert len(get(client, 7, limit=limit).json()["recommendations"]) == limit
    assert len(get(client, 42, limit=limit).json()["recommendations"]) == limit


def test_repeated_requests_are_identical(client):
    assert get(client, 15).json() == get(client, 15).json()


def test_debug_includes_score_breakdown(client):
    rec = get(client, 7, debug=True).json()["recommendations"][0]
    assert set(rec["score_breakdown"]) == {"relevance", "activity", "accessibility", "openness", "quality"}


# ---- planted scenarios ------------------------------------------------------

def test_cold_start_user_42(client):
    body = get(client, 42).json()
    assert body["strategy"] == "cold_start"
    recs = body["recommendations"]
    assert len(recs) == 10
    # No interest or membership is claimed for someone who has given us neither.
    assert not any(re.search(r"interest|already in", r["reason"]) for r in recs)
    # Breadth over a single assumed topic.
    topics = [r["topic"]["slug"] for r in recs if r["topic"]]
    assert len(set(topics)) == len(topics)


def test_obvious_matches_user_7(client):
    top3 = rec_ids(get(client, 7))[:3]
    assert 5 in top3 and 6 in top3


def test_duplicate_negotiation_circles_user_15(client):
    ids = rec_ids(get(client, 15, limit=20))
    assert not {10, 11, 12} <= set(ids)
    assert len({10, 11, 12} & set(ids[:5])) <= 2


def test_full_and_inactive_user_23(client):
    ids = rec_ids(get(client, 23, limit=20))
    assert ids[0] == 22
    assert 20 not in ids and 21 not in ids


# ---- properties over every user ---------------------------------------------

def test_every_user_gets_sensible_output(client, seed, unavailable):
    memberships = {}
    for m in seed["memberships"]:
        memberships.setdefault(m["user_id"], set()).add(m["circle_id"])
    for u in seed["users"]:
        r = get(client, u["id"])
        assert r.status_code == 200, u["id"]
        recs = r.json()["recommendations"]
        ids = [x["circle_id"] for x in recs]
        assert recs, f"user {u['id']} got no recommendations"
        assert len(ids) == len(set(ids)), f"duplicate ids for user {u['id']}"
        assert not set(ids) & memberships.get(u["id"], set()), f"already-joined Circle for user {u['id']}"
        assert not set(ids) & unavailable, f"unavailable Circle for user {u['id']}"
        assert [x["rank"] for x in recs] == list(range(1, len(recs) + 1))
        assert [x["score"] for x in recs] == sorted((x["score"] for x in recs), reverse=True)


def test_explanations_are_supported_by_the_data(client, seed):
    circles = {c["id"]: c for c in seed["circles"]}
    labels = {t["slug"]: t["label"].lower() for t in seed["topics"]}
    checked_topic_claims = checked_post_counts = 0
    for u in seed["users"]:
        interests = {labels[s] for s in u["topic_interests"]}
        for rec in get(client, u["id"]).json()["recommendations"]:
            reason, c = rec["reason"], circles[rec["circle_id"]]
            assert reason and len(reason) < 200
            # Any post count quoted must be the Circle's real count.
            for n in re.findall(r"(\d+) posts? in the last 30 days", reason):
                assert int(n) == c["feed_posts_30d"]
                checked_post_counts += 1
            if "active" in reason:
                assert c["feed_posts_30d"] >= 3
            if "open to new members" in reason:
                assert c["join_policy"] == "open"
            # Any topic the reason attributes to the member must be one she stated.
            for phrase in re.findall(r"(?:Covers|Focused on|touches on) ([a-z &-]+?)(?: and ([a-z &-]+?))?, (?:a topic|one of|both)", reason):
                for label in filter(None, phrase):
                    assert label in interests, (u["id"], reason)
                    checked_topic_claims += 1
    assert checked_topic_claims > 100 and checked_post_counts > 500   # the patterns really matched
