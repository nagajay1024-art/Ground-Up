from __future__ import annotations

import logging
import os
import sqlite3
from collections.abc import Iterator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Path as PathParam, Query, Request

from app import database as db
from app.schemas import HealthResponse, Recommendation, RecommendationResponse, ScoreBreakdown, Topic
from app.service import UserNotFound, format_ts, recommendations_for

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("app")

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA_DIR = ROOT / "data"
DEFAULT_DB_PATH = ROOT / "data" / "leanin.db"

MAX_LIMIT = 20


@asynccontextmanager
async def lifespan(app: FastAPI):
    db_path = Path(os.getenv("LEANIN_DB_PATH", DEFAULT_DB_PATH))
    if not db_path.exists():
        logger.info("Database not found at %s; building it from seed data", db_path)
        db.build_database(db_path, os.getenv("LEANIN_DATA_DIR", DEFAULT_DATA_DIR))
    app.state.db_path = db_path
    app.state.as_of = os.getenv("LEANIN_AS_OF") or None
    yield


app = FastAPI(
    title="Lean In Circle Recommendations",
    version="1.0.0",
    description="Ranked, explained Circle recommendations for Lean In members.",
    lifespan=lifespan,
)


def get_conn(request: Request) -> Iterator[sqlite3.Connection]:
    conn = db.connect(request.app.state.db_path)
    try:
        yield conn
    finally:
        conn.close()


@app.get("/health", response_model=HealthResponse, tags=["ops"])
def health(conn: sqlite3.Connection = Depends(get_conn)) -> HealthResponse:
    count = conn.execute("SELECT COUNT(*) FROM circles").fetchone()[0]
    return HealthResponse(status="ok", circles=count)


@app.get(
    "/api/v1/users/{user_id}/recommendations",
    response_model=RecommendationResponse,
    tags=["recommendations"],
    responses={404: {"description": "User not found"}},
)
def get_recommendations(
    request: Request,
    user_id: int = PathParam(..., ge=1, description="Member id"),
    limit: int = Query(10, ge=1, le=MAX_LIMIT, description="Maximum number of Circles to return"),
    debug: bool = Query(False, description="Include the internal score breakdown"),
    conn: sqlite3.Connection = Depends(get_conn),
) -> RecommendationResponse:
    try:
        result, as_of, labels = recommendations_for(conn, user_id, limit, request.app.state.as_of)
    except UserNotFound:
        raise HTTPException(status_code=404, detail=f"User {user_id} not found")

    logger.info(
        "recommendations user=%s strategy=%s returned=%d excluded=%s",
        user_id, result.strategy, len(result.items), result.excluded,
    )
    return RecommendationResponse(
        user_id=user_id,
        strategy=result.strategy,
        as_of=format_ts(as_of),
        recommendations=[
            Recommendation(
                rank=i,
                circle_id=sc.circle.id,
                name=sc.circle.name,
                slug=sc.circle.slug,
                topic=Topic(slug=sc.circle.topic, label=labels.get(sc.circle.topic, sc.circle.topic))
                if sc.circle.topic else None,
                format=sc.circle.format,
                join_policy=sc.circle.join_policy,
                member_count=sc.circle.member_count,
                spots_left=sc.circle.spots_left,
                score=sc.score,
                reason=sc.reason,
                score_breakdown=ScoreBreakdown(**sc.components) if debug else None,
            )
            for i, sc in enumerate(result.items, start=1)
        ],
    )
