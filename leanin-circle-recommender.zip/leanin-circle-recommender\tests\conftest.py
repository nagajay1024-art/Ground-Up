import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.database import build_database

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


@pytest.fixture(scope="session")
def client(tmp_path_factory):
    db_path = tmp_path_factory.mktemp("db") / "test.db"
    build_database(db_path, DATA_DIR)
    mp = pytest.MonkeyPatch()
    mp.setenv("LEANIN_DB_PATH", str(db_path))
    mp.delenv("LEANIN_AS_OF", raising=False)
    from app.main import app

    with TestClient(app) as c:
        yield c
    mp.undo()


@pytest.fixture(scope="session")
def seed():
    """Raw seed JSON, used to check API output independently of the app's own logic."""
    return {name: json.loads((DATA_DIR / f"{name}.json").read_text(encoding="utf-8"))
            for name in ("topics", "users", "circles", "memberships", "activity")}
