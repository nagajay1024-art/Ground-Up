# Technical Design: Circle Recommendations

**What I built.** A FastAPI endpoint, `GET /api/v1/users/{id}/recommendations`, that returns ranked Circles for a member, each with a one-sentence reason. Ranking is deterministic and rule-based, so every score traces back to data a member could see. With no feedback data to learn from, that traceability matters more than model sophistication.

**Architecture.** `database.py` (SQLite schema, seed loader, parameterized SQL) → `service.py` (rows → typed objects, reference time) → `recommender.py` (pure functions: eligibility, scoring, diversity, explanations) → `main.py` (HTTP, validation, errors). The recommender never touches the DB, so it is unit-tested with small synthetic Circles. The DB is built from the untouched seed JSON on first start.

**Ranking.**
1. **Hard filters.** Exclude Circles she has already joined and `unlisted` Circles. Exclude **full** Circles: `member_count ≥ max_members`, where a null cap means never full. Exclude **dormant** Circles: no activity in 60 days, or zero posts in 30 days with fewer than 5 chat messages. Last activity is the later of `last_activity_at` and the newest post, because the seed's timestamp sometimes lags real posts. Missing activity data counts as dormant. These are filters, not penalties, so a perfect topic match can't resurface them.
2. **Score** = weighted sum of [0,1] signals:
   - *Relevance* (0.55): exact topic match 1.0, tag match 0.5 (tags are noisy), name/description mention 0.3. Extra matched interests add a bounded bonus.
   - *Activity* (0.25): posts in 30 days, log chat volume, recency (10-day half-life), engagement per recent post.
   - *Accessibility* (0.08): virtual > hybrid > in-person, since Circles have no location; remote members get a steeper preference.
   - *Openness* (0.07): open > request.
   - *Profile quality* (0.05): has a description and a cover image.

   An exact match (up to 0.55) always beats a Circle with zero relevance (at most 0.45). Ties break on activity, then id.
3. **Cold start.** With no stated interests, the topics of her current Circles become implied interests at 0.6× weight. With neither (user 42), relevance is dropped and the weights shift to activity 0.55, accessibility 0.20, openness 0.15, quality 0.10, with a strong topic-repeat penalty so the list samples a range of topics instead of assuming one.
4. **Diversity.** Near-duplicates collapse to the strongest one. That means same topic **and** same format **and** a shared distinctive name stem (or near-identical description and tags), checked against the list and against Circles she's already in. A different format counts as a real choice. Each repeat of a shown topic is multiplied by 0.9 (0.5 for cold start).
5. **Explanations.** Templates use only facts in the data: matched interest, main topic, real post count, format, and "open to new members" only when it's true. A test checks every reason for all 100 users against the raw JSON.

**Database.** `users`, `topics`, `circles` (nullable topic FK, nullable cap), plus many-to-many `user_topic_interests`, `circle_tags` (free-form, no FK), `memberships` (PK `user_id, circle_id`, with `role`) and `activity_posts`. Indexes follow the request path: the membership PK answers "her Circles"; `(circle_id, role)` answers leaders; `(circle_id, created_at)` answers 30-day engagement; the topic/tag indexes support candidate retrieval. CHECK constraints enforce the enums. Fullness and dormancy are derived at query time, not stored, so they can't go stale.

**Tradeoffs.** No ML or embeddings: 40 Circles, no join feedback, and a need for honest explanations all favour rules. The weights are hand-set, not fitted, and I checked them across all 100 users instead of tuning to the four planted ones. Scoring scans every Circle per request, which is fine at 40 and not at 170k.

**Production scale.** Postgres with the same schema. Circle health features precomputed by a background job. Topic/tag-indexed candidate retrieval with this scorer as the re-ranker. Per-user caching, invalidated when she joins or changes interests. Log impressions, joins and hides to learn weights, and A/B test against join rate and 90-day Circle retention, not clicks. Add Circle location for in-person matching. Monitor latency, empty-result rate and score drift. Keep the recommender's PII minimal: it never needs names, bios or chat text.

**Limitations.** No bio or job-title understanding (deliberately: don't infer unexpressed interests). No industry or location matching (Circles lack those fields). No leader-quality signal. Duplicate detection is a heuristic. Tag matches can surface audience-specific Circles; for example, *Working Mothers United* reaches a "getting promoted" member through a tag. No auth or pagination.
