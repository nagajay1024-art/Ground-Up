"""Rebuild the SQLite database from the seed JSON.

    python -m scripts.load_data [--db data/leanin.db] [--data data]
"""

import argparse
import logging
from pathlib import Path

from app.database import build_database

ROOT = Path(__file__).resolve().parent.parent

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--db", default=ROOT / "data" / "leanin.db", type=Path)
    parser.add_argument("--data", default=ROOT / "data", type=Path)
    args = parser.parse_args()
    build_database(args.db, args.data)
