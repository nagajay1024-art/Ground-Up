"""Unit tests for ranking policy, using small synthetic Circles so each rule is tested in isolation."""

from datetime import datetime, timedelta, timezone

from app.recommender import Circle, UserContext, near_duplicates, recommend

AS_OF = datetime(2026, 9, 21, tzinfo=timezone.utc)
LABELS = {"negotiation": "Negotiation", "confidence": "Confidence", "networking": "Networking",
          "leadership-skills": "Leadership skills", "resilience": "Resilience", "allyship": "Allyship"}


def make_circle(id: int, topic: str | None = "negotiation", **kw) -> Circle:
    defaults = dict(
        id=id, name=f"Circle {id}", slug=f"circle-{id}", description=None, topic=topic,
        tags=(topic,) if topic else (), cover_image_url="https://img.example/x.jpg", format="virtual",
        access="public", join_policy="open", max_members=None, member_count=10,
        last_activity_at=AS_OF - timedelta(days=1), feed_posts_30d=10, chat_messages_30d=100,
        last_post_at=None, recent_posts=10, recent_engagement=120,
    )
    defaults.update(kw)
    return Circle(**defaults)


def user(interests=(), member_circles=(), location=None) -> UserContext:
    return UserContext(user_id=1, interests=tuple(interests), member_circles=tuple(member_circles), location=location)


def ids(result):
    return [sc.circle.id for sc in result.items]


# ---- availability & activity ------------------------------------------------

def test_full_circle_excluded_even_when_it_is_the_best_match():
    full = make_circle(1, max_members=12, member_count=12)
    healthy = make_circle(2, feed_posts_30d=3, chat_messages_30d=10)
    r = recommend(user(["negotiation"]), [full, healthy], LABELS, AS_OF)
    assert ids(r) == [2]
    assert r.excluded[1] == ["full"]


def test_uncapped_circle_is_never_full_regardless_of_size():
    big = make_circle(1, max_members=None, member_count=500)
    assert ids(recommend(user(["negotiation"]), [big], LABELS, AS_OF)) == [1]


def test_long_inactive_circle_excluded_despite_perfect_topic_match():
    stale = make_circle(1, last_activity_at=AS_OF - timedelta(days=200), feed_posts_30d=0,
                        chat_messages_30d=3, recent_posts=0, recent_engagement=0)
    off_topic = make_circle(2, topic="networking")
    r = recommend(user(["negotiation"]), [stale, off_topic], LABELS, AS_OF)
    assert 1 not in ids(r)
    assert "inactive" in r.excluded[1]


def test_missing_activity_timestamp_is_treated_as_inactive():
    unknown = make_circle(1, last_activity_at=None, last_post_at=None)
    assert recommend(user(["negotiation"]), [unknown], LABELS, AS_OF).excluded[1] == ["inactive"]


def test_recent_post_counts_even_if_last_activity_at_lags():
    c = make_circle(1, last_activity_at=AS_OF - timedelta(days=120), last_post_at=AS_OF - timedelta(days=2))
    assert ids(recommend(user(["negotiation"]), [c], LABELS, AS_OF)) == [1]


def test_no_posts_and_almost_no_chat_is_dormant():
    c = make_circle(1, feed_posts_30d=0, chat_messages_30d=2, recent_posts=0, recent_engagement=0)
    assert "inactive" in recommend(user(["negotiation"]), [c], LABELS, AS_OF).excluded[1]


def test_quieter_circle_ranks_below_active_one_on_same_topic():
    quiet = make_circle(1, feed_posts_30d=2, chat_messages_30d=8, recent_posts=2, recent_engagement=6,
                        last_activity_at=AS_OF - timedelta(days=20), format="hybrid")
    active = make_circle(2, format="in_person")
    assert ids(recommend(user(["negotiation"]), [quiet, active], LABELS, AS_OF))[0] == 2


# ---- relevance --------------------------------------------------------------

def test_topic_match_outranks_a_more_popular_irrelevant_circle():
    relevant = make_circle(1, feed_posts_30d=3, chat_messages_30d=10, recent_posts=3, recent_engagement=10,
                           format="in_person", join_policy="request")
    popular = make_circle(2, topic="networking", feed_posts_30d=30, chat_messages_30d=500, recent_engagement=600)
    assert ids(recommend(user(["negotiation"]), [relevant, popular], LABELS, AS_OF)) == [1, 2]


def test_primary_topic_beats_tag_only_match():
    tag_only = make_circle(1, topic="networking", tags=("networking", "negotiation"))
    primary = make_circle(2, topic="negotiation", format="in_person")
    assert ids(recommend(user(["negotiation"]), [tag_only, primary], LABELS, AS_OF))[0] == 2


def test_matching_two_interests_beats_matching_one():
    one = make_circle(1, topic="negotiation", tags=("negotiation",))
    two = make_circle(2, topic="negotiation", tags=("negotiation", "confidence"), name="Bargain Better")
    assert ids(recommend(user(["negotiation", "confidence"]), [one, two], LABELS, AS_OF))[0] == 2


# ---- duplicates & diversity -------------------------------------------------

def test_near_duplicates_collapse_to_the_strongest():
    a = make_circle(1, name="Negotiation Circle", format="in_person", feed_posts_30d=6)
    b = make_circle(2, name="Negotiate Like a Leader", format="in_person", feed_posts_30d=12)
    r = recommend(user(["negotiation"]), [a, b], LABELS, AS_OF)
    assert ids(r) == [2]


def test_same_topic_but_different_format_is_a_legitimate_choice():
    a = make_circle(1, name="Negotiation Circle", format="in_person")
    b = make_circle(2, name="The Negotiation Table", format="hybrid")
    assert not near_duplicates(a, b)
    assert sorted(ids(recommend(user(["negotiation"]), [a, b], LABELS, AS_OF))) == [1, 2]


def test_same_topic_with_distinct_identity_is_not_a_duplicate():
    a = make_circle(1, topic="leadership-skills", name="The Elevation Circle", format="in_person", tags=("allyship",))
    b = make_circle(2, topic="leadership-skills", name="Board-Ready Women", format="in_person", tags=("confidence",))
    assert not near_duplicates(a, b)


def test_near_duplicate_of_a_joined_circle_is_not_recommended():
    joined = make_circle(1, name="Negotiation Circle", format="in_person")
    dup = make_circle(2, name="Negotiate Like a Leader", format="in_person")
    other = make_circle(3, name="The Negotiation Table", format="hybrid")
    r = recommend(user(member_circles=[(1, joined.name, "negotiation")]), [joined, dup, other], LABELS, AS_OF)
    assert ids(r) == [3]


def test_cold_start_spreads_across_topics():
    # Distinct names, so this exercises topic diversity rather than duplicate collapsing.
    specs = [("negotiation", "Bold Asks"), ("negotiation", "Deal Room"), ("negotiation", "Fair Pay"),
             ("confidence", "Self Belief"), ("networking", "Connectors")]
    circles = [make_circle(i, topic=t, name=n) for i, (t, n) in enumerate(specs, start=1)]
    r = recommend(user(), circles, LABELS, AS_OF, limit=3)
    assert len({sc.circle.topic for sc in r.items}) == 3


# ---- eligibility & shape ----------------------------------------------------

def test_existing_memberships_and_unlisted_circles_excluded():
    joined, unlisted, ok = make_circle(1), make_circle(2, access="unlisted"), make_circle(3, format="hybrid")
    r = recommend(user(["negotiation"], member_circles=[(1, "Circle 1", "negotiation")]), [joined, unlisted, ok], LABELS, AS_OF)
    assert ids(r) == [3]
    assert r.excluded == {1: ["already_member"], 2: ["not_discoverable"]}


def test_limit_and_deterministic_tie_break():
    circles = [make_circle(i, topic=None, tags=()) for i in (5, 3, 9, 1)]   # identical except id
    r1 = recommend(user(), circles, LABELS, AS_OF, limit=3)
    r2 = recommend(user(), list(reversed(circles)), LABELS, AS_OF, limit=3)
    assert ids(r1) == ids(r2) == [1, 3, 5]


def test_no_eligible_circles_returns_empty_list():
    assert recommend(user(["negotiation"]), [make_circle(1, max_members=10, member_count=10)], LABELS, AS_OF).items == []


# ---- strategies & explanations ----------------------------------------------

def test_cold_start_reasons_do_not_claim_interests():
    r = recommend(user(), [make_circle(1), make_circle(2, topic="confidence")], LABELS, AS_OF)
    assert r.strategy == "cold_start" and len(r.items) == 2
    assert all("interest" not in sc.reason and "you're already" not in sc.reason for sc in r.items)


def test_membership_topics_used_when_no_stated_interests():
    joined = make_circle(1, name="Resilience Room", topic="resilience", format="hybrid")
    match = make_circle(2, name="Bounce Back", topic="resilience")
    other = make_circle(3, name="Grow Your Network", topic="networking")
    r = recommend(user(member_circles=[(1, "Resilience Room", "resilience")]), [joined, match, other], LABELS, AS_OF)
    assert r.strategy == "membership_topics"
    assert ids(r)[0] == 2
    assert "Resilience Room" in r.items[0].reason and "resilience" in r.items[0].reason


def test_reason_names_the_matched_interest():
    r = recommend(user(["negotiation"]), [make_circle(1)], LABELS, AS_OF)
    assert "negotiation" in r.items[0].reason


def test_reason_never_claims_activity_without_posts():
    # Recent chat keeps it eligible, but there are no feed posts to point to.
    c = make_circle(1, feed_posts_30d=0, chat_messages_30d=30, recent_posts=0, recent_engagement=0)
    for u in (user(["negotiation"]), user()):
        reason = recommend(u, [c], LABELS, AS_OF).items[0].reason
        assert "active" not in reason and "posts" not in reason


def test_missing_profile_fields_do_not_crash():
    c = make_circle(1, description=None, cover_image_url=None, tags=(), topic=None)
    r = recommend(UserContext(user_id=1, interests=(), member_circles=(), location=None), [c], LABELS, AS_OF)
    assert r.items[0].reason


def test_remote_member_prefers_virtual_when_otherwise_equal():
    in_person = make_circle(1, format="in_person", name="Table Talk")
    virtual = make_circle(2, format="virtual", name="Deal Makers")
    assert ids(recommend(user(["negotiation"], location="Remote"), [in_person, virtual], LABELS, AS_OF))[0] == 2


def test_returned_scores_are_sorted_and_bounded():
    circles = [make_circle(i, topic=t, name=f"{t} {i}", feed_posts_30d=i) for i, t in
               enumerate(["negotiation", "negotiation", "confidence", "networking", "negotiation"], start=1)]
    scores = [sc.score for sc in recommend(user(["negotiation"]), circles, LABELS, AS_OF).items]
    assert scores == sorted(scores, reverse=True)
    assert all(0 <= s <= 1 for s in scores)


def test_tag_match_reason_mentions_circle_focus():
    c = make_circle(1, topic="networking", tags=("networking", "negotiation"))
    reason = recommend(user(["negotiation"]), [c], LABELS, AS_OF).items[0].reason
    assert "networking" in reason and "negotiation" in reason
